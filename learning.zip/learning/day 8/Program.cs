﻿using System;

public class Program
{
    public static void Main()
    {
        //OptionalParameters(1);
        //NamedParameters(param1: 1, param2: "example");
        //OutParameters(out int result);
        //ReferenceParameters(ref result);
        //double area = AreaOfTriangle(3, 4, 5);
        //Console.WriteLine("Area of Triangle: " + area);
        //int sum = SumOfIntArray(new int[] { 1, 2, 3, 4, 5 });
        //Console.WriteLine("Sum of Int Array: " + sum);
        ExceptionHandling();
    }

    public static void OptionalParameters(int mandatoryParam, int optionalParam = 10)
    {
        Console.WriteLine("Optional Parameters:");
        Console.WriteLine($"Mandatory: {mandatoryParam}, Optional: {optionalParam}");
    }

    public static void NamedParameters(int param1, string param2)
    {
        Console.WriteLine("Named Parameters:");
        Console.WriteLine($"Param1: {param1}, Param2: {param2}");
    }

    public static void OutParameters(out int result)
    {
        result = 42;
        Console.WriteLine("Out Parameters:");
        Console.WriteLine($"Result: {result}");
    }

    public static void ReferenceParameters(ref int refParam)
    {
        refParam *= 2;
        Console.WriteLine("Reference Parameters:");
        Console.WriteLine($"Ref Param: {refParam}");
    }

    public static double AreaOfTriangle(double a, double b, double c)
    {
        double s = (a + b + c) / 2;
        double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));
        Console.WriteLine("Exercise - Area of a Triangle:");
        return area;
    }

    public static int SumOfIntArray(int[] numbers)
    {
        int sum = 0;
        foreach (int num in numbers)
        {
            sum += num;
        }
        Console.WriteLine("Exercise - Sum of int Array:");
        return sum;
    }

    public static void ExceptionHandling()
    {
        try
        {
            int[] array = new int[2];
            array[5] = 10;
        }
        catch (IndexOutOfRangeException e)
        {
            Console.WriteLine("Exception Handling:");
            Console.WriteLine(e.Message);
        }
    }
}
