﻿using System;

namespace Day_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //FizzBuzz();
            //VerbatimStringLiteral();
            //StringFormatting();
            //StringInterpolation();
            //StringConcatenation();
            //EmptyString();
            //StringEqualsFunction();
            //StringIterationLooping();
            //StringIsNullOrEmptyFunction();
            //PrintStringInReverse();
            //PasswordChecker();
        }

        static void FizzBuzz()
        {
            Console.WriteLine("FizzBuzz Game:");
            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                    Console.WriteLine("FizzBuzz");
                else if (i % 3 == 0)
                    Console.WriteLine("Fizz");
                else if (i % 5 == 0)
                    Console.WriteLine("Buzz");
                else
                    Console.WriteLine(i);
            }
        }

        static void VerbatimStringLiteral()
        {
            Console.WriteLine("Verbatim String Literal:");
            string path = @"C:\Users\Username\Documents\file.txt";
            Console.WriteLine(path);
        }

        static void StringFormatting()
        {
            Console.WriteLine("String Formatting:");
            string name = "Alice";
            int age = 30;
            string formattedString = string.Format("Name: {0}, Age: {1}", name, age);
            Console.WriteLine(formattedString);
        }

        static void StringInterpolation()
        {
            Console.WriteLine("String Interpolation:");
            string name = "Bob";
            int age = 25;
            string interpolatedString = $"Name: {name}, Age: {age}";
            Console.WriteLine(interpolatedString);
        }

        static void StringConcatenation()
        {
            Console.WriteLine("String Concatenation:");
            string part1 = "Hello, ";
            string part2 = "world!";
            string concatenatedString = part1 + part2;
            Console.WriteLine(concatenatedString);
        }

        static void EmptyString()
        {
            Console.WriteLine("Empty String:");
            string empty = "";
            if (string.IsNullOrEmpty(empty))
            {
                Console.WriteLine("The string is empty.");
            }
        }

        static void StringEqualsFunction()
        {
            Console.WriteLine("String Equals Function:");
            string str1 = "Hello";
            string str2 = "hello";
            bool areEqual = str1.Equals(str2, StringComparison.OrdinalIgnoreCase);
            Console.WriteLine($"Are '{str1}' and '{str2}' equal (ignore case)? {areEqual}");
        }

        static void StringIterationLooping()
        {
            Console.WriteLine("String Iteration Looping:");
            string str = "Iteration";
            foreach (char c in str)
            {
                Console.WriteLine(c);
            }
        }

        static void StringIsNullOrEmptyFunction()
        {
            Console.WriteLine("String IsNullOrEmpty Function:");
            string str1 = "";
            string str2 = null;
            string str3 = "Non-empty string";
            Console.WriteLine($"Is str1 null or empty? {string.IsNullOrEmpty(str1)}");
            Console.WriteLine($"Is str2 null or empty? {string.IsNullOrEmpty(str2)}");
            Console.WriteLine($"Is str3 null or empty? {string.IsNullOrEmpty(str3)}");
        }

        static void PrintStringInReverse()
        {
            Console.WriteLine("Print String in Reverse:");
            string str = "Reverse me";
            char[] charArray = str.ToCharArray();
            Array.Reverse(charArray);
            string reversedStr = new string(charArray);
            Console.WriteLine(reversedStr);
        }

        static void PasswordChecker()
        {
            Console.WriteLine("Password Checker:");
            string password = "P@ssw0rd!";
            bool isValid = password.Length >= 8 && 
                           password.IndexOfAny("0123456789".ToCharArray()) != -1 && 
                           password.IndexOfAny("ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()) != -1 && 
                           password.IndexOfAny("abcdefghijklmnopqrstuvwxyz".ToCharArray()) != -1 && 
                           password.IndexOfAny("!@#$%^&*()".ToCharArray()) != -1;
            Console.WriteLine($"Is the password '{password}' valid? {isValid}");
        }
    }
}
