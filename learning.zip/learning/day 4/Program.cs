﻿using System;

namespace Day_4
{
    class Program
    {
        static void Main(string[] args)
        {
            // instead of commenting out whole blocks, have all the code uncommented and then just... comment out the calling of the method.
            // Conditional operator example
            //ConditionalOperatorExample();

            // Numeric formatting example
            //NumericFormattingExample();

            // TryParse function example
            //TryParseExample();

            // Exercise - Times table
            //TimesTableExercise();
        }

        #region Conditional Operator
        static void ConditionalOperatorExample()
        {
            int a = 10, b = 20;
            string result = a > b ? "a is greater than b" : "a is not greater than b";
            Console.WriteLine("Conditional Operator Example:");
            Console.WriteLine(result);
            Console.WriteLine();
        }
        #endregion

        #region Numeric Formatting
        static void NumericFormattingExample()
        {
            double number = 1234.56789;

            Console.WriteLine("Numeric Formatting Example:");
            Console.WriteLine("Currency: {0:C}", number);     // Currency format
            Console.WriteLine("Fixed-point: {0:F2}", number); // Fixed-point format
            Console.WriteLine("Scientific: {0:E}", number);   // Scientific notation
            Console.WriteLine("Percent: {0:P}", number / 10000); // Percent format
            Console.WriteLine();
        }
        #endregion

        #region TryParse
        static void TryParseExample()
        {
            string input = "123";
            bool success = int.TryParse(input, out int result);

            Console.WriteLine("TryParse Example:");
            Console.WriteLine(success 
                ? $"Parsing succeeded: {result}" 
                : "Parsing failed.");
            Console.WriteLine();
        }
        #endregion

        #region Times Table Exercise
        static void TimesTableExercise()
        {
            int number = 5;
            Console.WriteLine("Times Table Exercise:");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} x {1} = {2}", number, i, number * i);
            }
            Console.WriteLine();
        }
        #endregion
    }
}
