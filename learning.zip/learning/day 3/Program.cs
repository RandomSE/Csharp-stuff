﻿using System;

namespace Day_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // switch
            /*
        Console.WriteLine("Enter a number between 1 and 5:");
        int number = Convert.ToInt32(Console.ReadLine());

        switch (number)
        {
            case 1:
                Console.WriteLine("You entered one.");
                break;
            case 2:
                Console.WriteLine("You entered two.");
                break;
            case 3:
                Console.WriteLine("You entered three.");
                break;
            case 4:
                Console.WriteLine("You entered four.");
                break;
            case 5:
                Console.WriteLine("You entered five.");
                break;
            default:
                Console.WriteLine("Number not between 1 and 5.");
                break;
        }
        
        */
        // For loop

        /*
        Console.WriteLine("Even numbers between 1 and 10:");

        for (int i = 1; i <= 10; i++)
        {
            if (i % 2 == 0)
            {
                Console.WriteLine(i);
            }
        }

        Console.WriteLine("Sum of first 10 natural numbers:");

        int sum = 0;
        for (int i = 1; i <= 10; i++)
        {
            sum += i;
        }
        Console.WriteLine("Sum: " + sum);
        */

        /*
        // While loop
        int number2 = 0;
        while (number2 < 10)
        {
            if (number2 % 2 == 0)
            {
                Console.WriteLine(number2 + " is even.");
            }
            else
            {
                Console.WriteLine(number2 + " is odd.");
            }
            number2++;
        }

        Console.WriteLine("Countdown from 5 to 1:");

        int countdown = 5;
        while (countdown > 0)
        {
            if (countdown == 3)
            {
                Console.WriteLine("Halfway there!");
            }
            Console.WriteLine(countdown);
            countdown--;
        }
        */
        }
    }
}
