﻿using System;

namespace day_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // remainer(modulus basically)
            Console.WriteLine(27 % 7);


            /*
            // var keyword
            var number = 10; // var keyword, compiler infers the type as int
            var message = "Hello, world!"; // var keyword, compiler infers the type as string

            Console.WriteLine(number);
            Console.WriteLine(message);
            */

    	    /*
            // System input,output + storing user data.

            const int MaxValue = 100; // const keyword, value cannot be changed
            System.Console.WriteLine("What is your name?"); // output
            String name = Console.ReadLine(); // input

            Console.WriteLine("How old are you in years?"); // output
            int age = Convert.ToInt32(Console.ReadLine()); // input
            Console.WriteLine("Hello, " + name + "! You are " + age + " years old."); // Output
            */

            // odd/even checker, if/else statement
            System.Console.WriteLine("Input an integer");
            int num = Convert.ToInt32(Console.ReadLine());
            int remainder = num % 2;
            if (remainder == 1){
            System.Console.WriteLine(num + " is odd.");
            }
            else{
            System.Console.WriteLine(num + " is even200.");
            }
        }
    }
}
