﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
       // DemonstrateDictionary();
       // ExerciseOddEvenNumberSplit();
       // ExerciseArrayOfMultiples();
       // DemonstrateFunctions();
       // DemonstrateVoidFunctions();
       // DemonstrateReturnTypeFunctions();
        DemonstrateFunctionParameters();
    }

    static void DemonstrateDictionary()
    {
        Console.WriteLine("Dictionary Example:");
        Dictionary<string, int> ages = new Dictionary<string, int>
        {
            { "Alice", 30 },
            { "Bob", 25 },
            { "Charlie", 35 }
        };

        foreach (var kvp in ages)
        {
            Console.WriteLine($"{kvp.Key}: {kvp.Value}");
        }
    }

    static void ExerciseOddEvenNumberSplit()
    {
        Console.WriteLine("Odd/Even Number Split:");
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        List<int> oddNumbers = new List<int>();
        List<int> evenNumbers = new List<int>();

        foreach (var number in numbers)
        {
            if (number % 2 == 0)
            {
                evenNumbers.Add(number);
            }
            else
            {
                oddNumbers.Add(number);
            }
        }

        Console.WriteLine("Odd Numbers: " + string.Join(", ", oddNumbers));
        Console.WriteLine("Even Numbers: " + string.Join(", ", evenNumbers));
    }

    static void ExerciseArrayOfMultiples()
    {
        Console.WriteLine("Array of Multiples:");
        int number = 5;
        int length = 10;
        int[] multiples = new int[length];

        for (int i = 0; i < length; i++)
        {
            multiples[i] = number * (i + 1);
        }

        Console.WriteLine("Multiples: " + string.Join(", ", multiples));
    }

    static void DemonstrateFunctions()
    {
        Console.WriteLine("Functions Example:");
        int result = Add(3, 4);
        Console.WriteLine("Add(3, 4) = " + result);
    }

    static int Add(int a, int b)
    {
        return a + b;
    }

    static void DemonstrateVoidFunctions()
    {
        Console.WriteLine("Void Functions Example:");
        PrintMessage("Hello, world!");
    }

    static void PrintMessage(string message)
    {
        Console.WriteLine(message);
    }

    static void DemonstrateReturnTypeFunctions()
    {
        Console.WriteLine("Return Type Functions Example:");
        double area = CalculateArea(5.0);
        Console.WriteLine("CalculateArea(5.0) = " + area);
    }

    static double CalculateArea(double radius)
    {
        return Math.PI * radius * radius;
    }

    static void DemonstrateFunctionParameters()
    {
        Console.WriteLine("Function Parameters Example:");
        GreetUser("Alice", 30);
    }

    static void GreetUser(string name, int age)
    {
        Console.WriteLine($"Hello {name}, you are {age} years old.");
    }
}
