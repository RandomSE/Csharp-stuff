﻿using System;
using System.Text;
using System.Globalization;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            // so far, c# seems pretty similar to Java. neat.
            string greeting = "Hello, World!";
            Console.WriteLine(greeting);

            /*
            // Numeric data types: for double, you put a D at the end. for float, a F.  Decimal  an M, Long  an L. the other variations such as 
            // the s and u prefixes are for Signed and Unsigned respectively; a signed integer supports positive and negative values, an unsigned integer only supports positive values and zero.
            // if an integer type has only an s variant, it is naturally unsigned, and vice versa. Unsigned variants can have either the normal end for that type (like L for long) or U + normal end.
            byte byteValue = 255;
            sbyte sbyteValue = -128;
            short shortValue = -32768;
            ushort ushortValue = 65535;
            int intValue = 2147483647;
            uint uintValue = 4294967295U;
            long longValue = 9223372036854775807L;
            ulong ulongValue = 18446744073709551615UL;

            float floatValue = 3.14F;
            double doubleValue = 3.14D;
            decimal decimalValue = 3.14M;

            Console.WriteLine($"byte: {byteValue}");
            Console.WriteLine($"sbyte: {sbyteValue}");
            Console.WriteLine($"short: {shortValue}");
            Console.WriteLine($"ushort: {ushortValue}");
            Console.WriteLine($"int: {intValue}");
            Console.WriteLine($"uint: {uintValue}");
            Console.WriteLine($"long: {longValue}");
            Console.WriteLine($"ulong: {ulongValue}");
            Console.WriteLine($"float: {floatValue}");
            Console.WriteLine($"double: {doubleValue}");
            Console.WriteLine($"decimal: {decimalValue}");

            */


            /*
            // Text-based data types. (string is above)
            char letter = 'A';
            Console.WriteLine(letter);

            StringBuilder sb = new StringBuilder("This is more complex, ");
            sb.Append("than a basic string. Basically, ");
            sb.Append("it's very similar to a list."); // meaning can do replace, remove, insert, append etc.
            Console.WriteLine(sb.ToString());
            */

                        
            /*
            // Converting strings to number data types with error management

            // Example 1: Converting string to int
            string numberStr = "123";
            int number;
            bool success = int.TryParse(numberStr, out number);
            if (success)
            {
                Console.WriteLine($"Successfully converted '{numberStr}' to int: {number}");
            }
            else
            {
                Console.WriteLine($"Failed to convert '{numberStr}' to int.");
            }

            // Converting string to double
            string doubleStr = "3.14";
            double doubleNumber;
            success = double.TryParse(doubleStr, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out doubleNumber); 
            if (success)
            {
                Console.WriteLine($"Successfully converted '{doubleStr}' to double: {doubleNumber}");
            }
            else
            {
                Console.WriteLine($"Failed to convert '{doubleStr}' to double.");
            }

            // conversion errors
            string invalidStr = "abc";
            int result;
            try
            {
                result = int.Parse(invalidStr); // This will throw FormatException
                Console.WriteLine($"Converted '{invalidStr}' to int: {result}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"Error converting '{invalidStr}' to int: {ex.Message}"); // basic formatting.
            }
            */


            /*
            // Boolean data types

            //Boolean variables
            bool isTrue = true;
            bool isFalse = false;

            //  Boolean expressions
            int a = 5;
            int b = 10;
            bool isEqual = (a == b);    // false
            bool isGreater = (a > b);   // false
            bool isLessOrEqual = (a <= b); // true

            // Conditional statements with boolean expressions
            if (isTrue)
            {
                Console.WriteLine("It's true!");
            }
            else
            {
                Console.WriteLine("It's false!");
            }

            //  Logical operators
            bool condition1 = true;
            bool condition2 = false;
            bool logicalAnd = condition1 && condition2; // false
            bool logicalOr = condition1 || condition2;  // true
            bool logicalNot = !condition1;              // false
            */


            /*
            // Uses of all operators

            // Arithmetic operators
            int x = 10;
            int y = 3;
            int addition = x + y;       // 13
            int subtraction = x - y;    // 7
            int multiplication = x * y; // 30
            int division = x / y;       // 3
            int modulus = x % y;        // 1 // remainder.

            // Assignment operators
            int z = 5;
            z += 3; // Equivalent to z = z + 3
            z -= 2; // Equivalent to z = z - 2
            z *= 4; // Equivalent to z = z * 4
            z /= 2; // Equivalent to z = z / 2
            z %= 3; // Equivalent to z = z % 3

            // Comparison operators
            bool isEqual = (x == y);    // false
            bool isNotEqual = (x != y); // true
            bool isGreater = (x > y);   // true
            bool isLess = (x < y);      // false
            bool isGreaterOrEqual = (x >= y); // true
            bool isLessOrEqual = (x <= y);    // false

            // Logical operators
            bool condition1 = true;
            bool condition2 = false;
            bool logicalAnd = condition1 && condition2; // false
            bool logicalOr = condition1 || condition2;  // true
            bool logicalNot = !condition1;              // false

            // Bitwise operators (for integers) // Bitwise is good to know for binary manipulation and performance optimization.
            int num1 = 5;   // 101 in binary
            int num2 = 3;   // 011 in binary

            // Bitwise AND (&)
            int bitwiseAnd = num1 & num2;   // 101 & 011 = 001 (1 in decimal)

            // Bitwise OR (|)
            int bitwiseOr = num1 | num2;    // 101 | 011 = 111 (7 in decimal)

            // Bitwise XOR (^)
            int bitwiseXor = num1 ^ num2;   // 101 ^ 011 = 110 (6 in decimal)

            // Bitwise Complement (~)
            int bitwiseComplement = ~num1;  // ~101 = 11111111111111111111111111111010 (-6 in decimal)

            // Left Shift (<<)
            int leftShift = num1 << 1;      // 101 << 1 = 1010 (10 in decimal)

            // Right Shift (>>)
            int rightShift = num1 >> 1;     // 101 >> 1 = 10 (2 in decimal)
            
            System.Console.WriteLine(bitwiseAnd);
            System.Console.WriteLine(bitwiseOr);
            System.Console.WriteLine(bitwiseXor);
            System.Console.WriteLine(bitwiseComplement);
            System.Console.WriteLine(leftShift);
            System.Console.WriteLine(rightShift);
            */

        }
    }
}
