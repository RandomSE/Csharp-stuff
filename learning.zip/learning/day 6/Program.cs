﻿using System;
using System.Collections.Generic;

namespace Day_6
{
    class Program
    {
        static void Main(string[] args)
        {
           // Arrays();
            //ArraySorting();
            //ArrayReversal();
            //ArrayClearing();
            //ArrayIndexOf();
            Lists();
        }

        static void Arrays()
        {
            int[] numbers = { 10, 22, 35, 47, 59, 62, 71, 84, 95, 106 };
            Console.WriteLine("Array elements:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }

        static void ArraySorting()
        {
            int[] numbers = { 52, 13, 84, 19, 24, 76, 33, 58, 91, 40 };
            Console.WriteLine("Array before sorting:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }

            Array.Sort(numbers);
            Console.WriteLine("Array after sorting:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }

        static void ArrayReversal()
        {
            int[] numbers = { 5, 11, 25, 37, 48, 59, 62, 73, 84, 95 };
            Console.WriteLine("Array before reversal:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }

            Array.Reverse(numbers);
            Console.WriteLine("Array after reversal:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }

        static void ArrayClearing()
        {
            int[] numbers = { 15, 29, 38, 47, 56, 65, 74, 83, 92, 101 };
            Console.WriteLine("Array before clearing:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }

            Array.Clear(numbers, 0, numbers.Length);
            Console.WriteLine("Array after clearing:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }

        static void ArrayIndexOf()
        {
            int[] numbers = { 23, 36, 49, 52, 68, 71, 84, 97, 100, 115 };
            int index = Array.IndexOf(numbers, 71);
            Console.WriteLine("Index of 71 in array: " + index);
        }

        static void Lists()
        {
            List<int> numbers = new List<int> { 13, 26, 39, 45, 58, 63, 72, 89, 94, 107 };
            Console.WriteLine("List elements:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }

            numbers.Add(120);
            Console.WriteLine("List after adding 120:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }

            numbers.Remove(39);
            Console.WriteLine("List after removing 39:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }
    }
}
