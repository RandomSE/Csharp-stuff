﻿using System;

namespace CSharpClassExamples
{
    class Program
    {
        static void Main(string[] args)
        {
           // ClassFunctionsExample();
            //ClassFieldsExample();
           // ClassVariableFunctionScopeExample();
           // ClassPropertiesExample();
            ClassToStringOverrideExample();
        }

        static void ClassFunctionsExample()
        {
            Console.WriteLine("ClassFunctionsExample");
            MyClass myClass = new MyClass();
            myClass.Greet();
        }

        static void ClassFieldsExample()
        {
            Console.WriteLine("ClassFieldsExample");
            MyClassWithFields myClassWithFields = new MyClassWithFields();
            myClassWithFields.name = "Alice";
            myClassWithFields.age = 25;
            Console.WriteLine("Name: " + myClassWithFields.name + ", Age: " + myClassWithFields.age);
        }

        static void ClassVariableFunctionScopeExample()
        {
            Console.WriteLine("ClassVariableFunctionScopeExample");
            MyClassWithScope myClassWithScope = new MyClassWithScope();
            myClassWithScope.SetValues(10, 20);
            myClassWithScope.PrintValues();
        }

        static void ClassPropertiesExample()
        {
            Console.WriteLine("ClassPropertiesExample");
            MyClassWithProperties myClassWithProperties = new MyClassWithProperties();
            myClassWithProperties.Name = "Bob";
            myClassWithProperties.Age = 30;
            Console.WriteLine("Name: " + myClassWithProperties.Name + ", Age: " + myClassWithProperties.Age);
        }

        static void ClassToStringOverrideExample()
        {
            Console.WriteLine("ClassToStringOverrideExample");
            MyClassWithToStringOverride myClassWithToStringOverride = new MyClassWithToStringOverride("Charlie", 35);
            Console.WriteLine(myClassWithToStringOverride.ToString());
        }

        class MyClass
        {
            public void Greet()
            {
                Console.WriteLine("Hello from MyClass!");
            }
        }

        class MyClassWithFields
        {
            public string name;
            public int age;
        }

        class MyClassWithScope
        {
            private int x;
            private int y;

            public void SetValues(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public void PrintValues()
            {
                Console.WriteLine("X: " + x + ", Y: " + y);
            }
        }

        class MyClassWithProperties
        {
            private string name;
            private int age;

            public string Name
            {
                get { return name; }
                set { name = value; }
            }

            public int Age
            {
                get { return age; }
                set { age = value; }
            }
        }

        class MyClassWithToStringOverride
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public MyClassWithToStringOverride(string name, int age)
            {
                Name = name;
                Age = age;
            }

            public override string ToString()
            {
                return "Name: " + Name + ", Age: " + Age;
            }
        }
    }
}
