﻿using System;

namespace CSharpExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            //TryCatchExample();
           // PrintErrorMessageExample();
            //CustomTryParseExample();
           // DebuggingExample();
            //LocalAutoWindowExample();
           // WatchWindowExample();
           // FixLogicErrorExample();
           // StructureExample();
            ClassExample();
        }

        static void TryCatchExample()
        {
            Console.WriteLine("TryCatchExample");
            try
            {
                int result = 10 / int.Parse("0");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Caught exception: " + ex.Message);
            }
        }

        static void PrintErrorMessageExample()
        {
            Console.WriteLine("PrintErrorMessageExample");
            try
            {
                int[] numbers = { 1, 2, 3 };
                Console.WriteLine(numbers[5]);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static bool CustomTryParse(string input, out int result)
        {
            Console.WriteLine("CustomTryParseExample");
            result = 0;
            try
            {
                result = int.Parse(input);
                return true;
            }
            catch
            {
                return false;
            }
        }

        static void CustomTryParseExample()
        {
            int number;
            if (CustomTryParse("123", out number))
            {
                Console.WriteLine("Parsed successfully: " + number);
            }
            else
            {
                Console.WriteLine("Parsing failed.");
            }
        }

        static void DebuggingExample()
        {
            Console.WriteLine("DebuggingExample");
            int a = 5;
            int b = 0;
            // Use debugger to step through the next line
            int result = a / b;
        }

        static void LocalAutoWindowExample()
        {
            Console.WriteLine("LocalAutoWindowExample");
            int x = 10;
            int y = 20;
            int sum = x + y;
            Console.WriteLine("Sum: " + sum);
        }

        static void WatchWindowExample()
        {
            Console.WriteLine("WatchWindowExample");
            int x = 30;
            int y = 40;
            int product = x * y;
            Console.WriteLine("Product: " + product);
        }

        static void FixLogicErrorExample()
        {
            Console.WriteLine("FixLogicErrorExample");
            int[] numbers = { 1, 2, 3, 4, 5 };
            int sum = 0;
            for (int i = 0; i <= numbers.Length; i++) // Logic error: should be i < numbers.Length
            {
                sum += numbers[i];
            }
            Console.WriteLine("Sum: " + sum);
        }

        struct Point
        {
            public int X;
            public int Y;

            public Point(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        static void StructureExample()
        {
            Console.WriteLine("StructureExample");
            Point p = new Point(10, 20);
            Console.WriteLine("Point: (" + p.X + ", " + p.Y + ")");
        }

        class Person
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public Person(string name, int age)
            {
                Name = name;
                Age = age;
            }

            public void Introduce()
            {
                Console.WriteLine("Hello, my name is " + Name + " and I am " + Age + " years old.");
            }
        }

        static void ClassExample()
        {
            Console.WriteLine("ClassExample");
            Person person = new Person("John Doe", 30);
            person.Introduce();
        }
    }
}
